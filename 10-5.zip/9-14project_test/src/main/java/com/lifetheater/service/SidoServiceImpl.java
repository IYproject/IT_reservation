package com.lifetheater.service;

import org.springframework.stereotype.Service;

@Service
public class SidoServiceImpl implements SidoService {

}
