package com.lifetheater.service;

public interface BoardService {

}
