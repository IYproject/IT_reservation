package com.lifetheater.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lifetheater.vo.GugunVO;
import com.lifetheater.vo.TheaterVO;

@Service
public interface GugunService {

	List<GugunVO> getGugun(int sido_code);

	List<TheaterVO> getGugunName(String gugun_name);

}
