package com.lifetheater.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.lifetheater.service.GugunService;
import com.lifetheater.service.SidoService;
import com.lifetheater.service.TheaterService;
import com.lifetheater.vo.GugunVO;

@Controller
public class IY_reservation {
	
	
	@Autowired
	private TheaterService theaterService;
	private SidoService sidoService;
	
	
	
	@GetMapping("IY_re01")
	public String fastreservation01() {
		return "reservation/re11";
	}
	
	
	@GetMapping("IY_res-conts")
	public String resConts(){
		
		return "reservation/res-conts";
	}

	@GetMapping("IY_re02")
	public String fastreservation02() {
		return "reservation/re02";
	}
	@GetMapping("IY_re03")
	public String fastreservation03() {
		return "reservation/re03";
	}
	
}
