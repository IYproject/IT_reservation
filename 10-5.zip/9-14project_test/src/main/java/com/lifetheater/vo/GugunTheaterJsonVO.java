package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GugunTheaterJsonVO {
	
	private String gugun_nameI;
	private String theater;

}
