package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FReply {
  private int freply_num;
  private int fboard_num;
  private String fb_reply_cont;
  private String fb_reply_date;
  private String fb_reply_reply;
  private String fb_img_url;
}
