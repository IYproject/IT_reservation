package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SidoGugunJsonVO {
	
	private String sido_codeI;
	private String gugun_code;

}
