package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TheaterVO {

	private String theater_code;
	private String theater;
	private String to_date;
	private String from_date;
	private int sido_code;
	private String sido_name;
	private int gugun_code;
	private String gugun_name;
	private int age_grade;
	private String actor;
	private int price;
	private String image1;
	private String status;
	private int runningtime;
	private String runidentifedcode;
	private String runtime;
}




