package com.lifetheater.vo;

public class TicketVO {
  private String ticket_code;
  private int cost;
  private int seat;
}
