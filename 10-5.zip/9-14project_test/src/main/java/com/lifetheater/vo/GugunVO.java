package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GugunVO {

	private int gugun_code;
	private String gugun_name;
	private int sido_code;
}


