package com.lifetheater.dao;


public class TheaterDAOImpl implements TheaterDAO {

	
	
}
