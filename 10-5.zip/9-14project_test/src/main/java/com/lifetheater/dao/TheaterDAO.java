package com.lifetheater.dao;

public interface TheaterDAO {

}
