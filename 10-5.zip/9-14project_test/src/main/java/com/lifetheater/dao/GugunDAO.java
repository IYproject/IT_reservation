package com.lifetheater.dao;

import java.util.List;

import com.lifetheater.vo.GugunVO;
import com.lifetheater.vo.TheaterVO;

public interface GugunDAO {

	List<GugunVO> getGugun(int sido_code);

	List<TheaterVO> getGugunName(String gugun_name);

}
