package com.lifetheater.dao;

public class SidoDAOImpl implements SidoDAO {

}
