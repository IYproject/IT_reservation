package com.lifetheater.dao;

public interface SidoDAO {

}
