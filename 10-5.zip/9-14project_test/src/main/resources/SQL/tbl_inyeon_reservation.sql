-- tbl_inyeon_reservation

create table tbl_inyeon_reservation(

  res_code varchar2(20) primary key-- 예약 테이블
  ,ticket_code1 varchar2(20) not null --티켓 코드
  ,ticket_code2 varchar2(20)
  ,ticket_code3 varchar2(20)
  ,ticket_code4 varchar2(20)
  ,location_code varchar2(100) not null -- 장소 코드
  ,theater_code varchar2(100) not null -- 극장 코드
  ,email varchar2(100)--user테이블 email외래키
  )
  

  
-- tbl_inyeon_ticket
create table tbl_inyeon_ticket(--티켓 테이블
  ticket_code varchar2(20) primary key --티켓 코드
  ,cost int  --티켓 비용 (1개당)
  ,seat varchar2(20) --좌석 정원
)

create table theater(
theater_code varchar2(50) primary key,
theater varchar2(50) not null,
to_date varchar2(20),
from_date varchar2(20),
sido_code int,
sido_name varchar2(100),
gugun_code int,
gugun_name varchar2(100),
age_grade int, 
actor varchar2(20),
price int,
image1 varchar2(30),
status varchar2(10),
runningtime int, 
runidentifedcode varchar2(50),
runtime varchar2(100)
);


select * from theater;

insert into theater values('abcd', '다만 악에서 구하소서', '2020-09-21' , '2020-09-30',11,'서울특별시',1111,'서울특별시종로구',19,'신지환',
+10000,'이미지','Y',2,'aqweaszxqw','화요일~금요일(20:00),토요일(16:00,19:00),일요일(15:00,18:00)');

insert into theater values('abcdqwe', '구하소서', '2020-09-21' , '2020-09-30',11,'서울특별시',1111,'서울특별시종로구',19,'신지환',
+10000,'이미지','Y',2,'qwwwezxc','화요일~금요일(19:00),토요일(16:00,19:00),일요일(15:00,18:00)');

insert into theater values('abcde', '혜진이와 아이들', '2020-09-21' , '2020-09-30',26,'부산어딘가',2611,'부산광역시중구',19,'신지환',
+10000,'이미지','Y',2,'aqweasa','화요일~금요일(18:00),토요일(16:00,19:00),일요일(15:00,18:00)'); 

insert into theater values('abcdef', '신효창', '2020-09-21' , '2020-09-30',41,'부산어딘가',2614,'부산광역시서구',19,'신지환',
+20000,'이미지','Y',2,'aqweasaasd','화요일~금요일(17:00),토요일(16:00,19:00),일요일(15:00,18:00)');



create table sido(
sido_code int primary key,
sido_name varchar2(30)
);

insert into sido values(11,'서울특별시');
insert into sido values(26,'부산광역시');
insert into sido values(27,'대구광역시');
insert into sido values(28,'인천광역시');
insert into sido values(29,'광주광역시');
insert into sido values(30,'대전광역시');
insert into sido values(31,'울산광역시');
insert into sido values(36,'세종특별자치시');
insert into sido values(41,'경기도');
insert into sido values(42,'강원도');
insert into sido values(43,'충청북도');
insert into sido values(44,'충청남도');
insert into sido values(45,'전라북도');
insert into sido values(46,'전라남도');
insert into sido values(47,'경상북도');
insert into sido values(48,'경상남도');
insert into sido values(50,'제주특별자치도');

select * from sido;



create table gugun(
gugun_code int primary key,
gugun_name varchar2(30),
sido_code int
);

insert into gugun values(1111 ,'서울특별시종로구',11);
insert into gugun values(1114 ,'서울특별시중구',11);
insert into gugun values(1117 ,'서울특별시용산구',11);
insert into gugun values(1120 ,'서울특별시성동구',11);
insert into gugun values(1121 ,'서울특별시광진구',11);
insert into gugun values(1123 ,'서울특별시동대문구',11);
insert into gugun values(1126 ,'서울특별시중랑구',11);
insert into gugun values(1129 ,'서울특별시성북구',11);
insert into gugun values(1130 ,'서울특별시강북구',11);
insert into gugun values(1132 ,'서울특별시도봉구',11);
insert into gugun values(1135 ,'서울특별시노원구',11);
insert into gugun values(1138 ,'서울특별시은평구',11);
insert into gugun values(1141 ,'서울특별시서대문구',11);
insert into gugun values(1144 ,'서울특별시마포구',11);
insert into gugun values(1147 ,'서울특별시양천구',11);
insert into gugun values(1150 ,'서울특별시강서구',11);
insert into gugun values(1153 ,'서울특별시구로구',11);
insert into gugun values(1154 ,'서울특별시금천구',11);
insert into gugun values(1156 ,'서울특별시영등포구',11);
insert into gugun values(1159 ,'서울특별시동작구',11);
insert into gugun values(1162 ,'서울특별시관악구',11);
insert into gugun values(1165 ,'서울특별시서초구',11);
insert into gugun values(1168 ,'서울특별시강남구',11);
insert into gugun values(1171 ,'서울특별시송파구',11);
insert into gugun values(1174 ,'서울특별시강북구',11);

insert into gugun values(2600,'부산광역시',26);
insert into gugun values(2611 ,'부산광역시중구',26);
insert into gugun values(2614 ,'부산광역시서구',26);



select * from gugun;








